package certa.modbus.samples;

import static certa.modbus.ModbusConstants.FN_READ_COILS;
import static certa.modbus.ModbusConstants.FN_READ_DISCRETE_INPUTS;

import certa.modbus.client.ModbusClient;
import certa.modbus.client.RtuTransportJssc;
import jssc.SerialPort;

public class TestPoll {

	public static void main(String[] args) {
	
		if (args.length < 4) {
			System.out.println("Command line parameters: <COM#> <function> <address> <count>");
			return;
		}
		
		ModbusClient mc = new ModbusClient();
		mc.setTransport(new RtuTransportJssc(args[0], 9600, 8, SerialPort.PARITY_NONE, SerialPort.STOPBITS_2, 1000, 5));
		
		String reg = "";
		if ("1".equals(args[1])) {
			reg = "Coil_";
			mc.InitReadCoilsRequest(1, Integer.parseInt(args[2]), Integer.parseInt(args[3]));
		} else if ("2".equals(args[1])) {
			reg = "DInput_";
			mc.InitReadDInputsRequest(1, Integer.parseInt(args[2]), Integer.parseInt(args[3]));
		} else if ("3".equals(args[1])) {
			reg = "HR_";
			mc.InitReadHoldingsRequest(1, Integer.parseInt(args[2]), Integer.parseInt(args[3]));
		} else if ("4".equals(args[1])) {
			reg = "IR_";
			mc.InitReadAInputsRequest(1, Integer.parseInt(args[2]), Integer.parseInt(args[3]));
		}

		try {
			mc.execRequest();
			if (mc.getResult() == ModbusClient.RESULT_OK) {
				if ((mc.getFunction() == FN_READ_COILS) || (mc.getFunction() == FN_READ_DISCRETE_INPUTS)) {
					for (int i = 0; i < mc.getResponseCount(); i++)
						System.out.println(reg + i + " = " + mc.getResponseBit(mc.getResponseAddress() + i));
				} else {
					for (int i = 0; i < mc.getResponseCount(); i++)
						System.out.println(reg + i + " = " + mc.getResponseRegister(mc.getResponseAddress() + i, false) + " (" + mc.getResponseRegister(mc.getResponseAddress() + i, true) + ")");
				}
			} else
				System.out.println(mc.getResultAsString());
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			mc.close();
		}
		
	}

}
