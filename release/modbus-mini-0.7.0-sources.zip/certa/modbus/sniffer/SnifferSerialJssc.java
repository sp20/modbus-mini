package certa.modbus.sniffer;

import static certa.modbus.ModbusConstants.*;

import certa.modbus.ModbusPdu;
import certa.modbus.client.ModbusClient;
import certa.modbus.client.RtuTransportJssc;
import jssc.SerialPort;
import jssc.SerialPortException;

public class SnifferSerialJssc {

	static SerialPort port;
	static protected final byte[] buffer = new byte[MAX_PDU_SIZE + 3];
	
	static protected boolean readToBuffer(int start, int length, int timeout) throws SerialPortException, InterruptedException {
		long now = System.currentTimeMillis();
		long deadline = now + timeout;
		int offset = start;
		int bytesToRead = length;
		boolean lastTry = false;
		while (bytesToRead > 0) {
			int avail = Math.min(port.getInputBufferBytesCount(), bytesToRead);
			if (avail > 0) {
				byte[] buf = port.readBytes(avail);
				avail = buf.length;
				System.arraycopy(buf, 0, buffer, offset, avail);
				offset += avail;
				bytesToRead -= avail;
			}
			if (bytesToRead > 0) {
				Thread.sleep(20);
				now = System.currentTimeMillis();
				// After reaching deadline we need to make last attempt to read data.
				// It is possible that something present in input buffer
				// (happens on heavy loaded virtual server)
				if ((timeout > 0) && (now > deadline)) {
					if (lastTry)
						break;
					else
						lastTry = true;
				}
			}
		}
		int res = length - bytesToRead; // total bytes read
		if (res < length) {
			System.out.println("TIMEOUT");
			if (res > 0)
				System.out.println("Last bytes: " + ModbusPdu.toHex(buffer, 0, start + res));
			return false;
		}
		else
			return true;
	}

	public static void main(String[] args) {
	
		port = new SerialPort("COM5");
		try {
			port.openPort();
			port.setParams(9600, 8, SerialPort.STOPBITS_2, SerialPort.PARITY_NONE);
			System.out.println("Sniffer started. Press Ctrl+C to exit");
			System.out.println("");
			
			while(true) {
				// Request from master
				// id, func
				readToBuffer(0, 2, 0);  // wait infinite
				int id = buffer[0];
				int func = buffer[1];
				String fstr = "";
				if (func == 1)
					fstr = "01 (Read Coils)";
				else if (func == 2)
					fstr = "02 (Read Discrete Inputs)";
				else if (func == 3)
					fstr = "03 (Read Holding Registers)";
				else if (func == 4)
					fstr = "04 (Read Input Registers)";
				else if (func == 5)
					fstr = "05 (Write Single Coil)";
				else if (func == 6)
					fstr = "06 (Write Single Register)";
				else if (func == 15)
					fstr = "15 (Write Multiple Coils)";
				else if (func == 16)
					fstr = "16 (Write Multiple registers)";
				if ((func == 1) || (func == 2)) {
					if (!readToBuffer(2, 6, 100))
						continue;
					int addr = ModbusPdu.bytesToInt16(buffer[3], buffer[2], true);
					int count = ModbusPdu.bytesToInt16(buffer[5], buffer[4], true);
					int crc = ModbusPdu.bytesToInt16(buffer[6], buffer[7], true);
					int calcCrc = ModbusPdu.calcCRC16(buffer, 0, 6);
					System.out.println("Request: " + ModbusPdu.toHex(buffer, 0, 8));
					System.out.println("ID: " + id + ", Fn: " + fstr + ", addr: " + addr + ", count: " + count + ", CRC: " + Integer.toHexString(crc) + ((crc != calcCrc) ? " WRONG CRC! Must be "+Integer.toHexString(calcCrc) : ""));
					if ((count < 1) || (count > MAX_READ_COILS))
						System.out.println("BAD REGISTERS COUNT: " + count);
					else {
						// Response
						int size = ModbusPdu.bytesCount(count);
						if (!readToBuffer(0, size+5, 500))
							continue;
						int id2 = buffer[0];
						int func2 = buffer[1];
						int size2 = ((int) buffer[2]) & 0xFF;
						crc = ModbusPdu.bytesToInt16(buffer[size+3], buffer[size+4], true);
						calcCrc = ModbusPdu.calcCRC16(buffer, 0, size+3);
						System.out.println("Response: " + ModbusPdu.toHex(buffer, 0, size+5));
						System.out.println("ID: " + id2 + ", Fn: " + func2 + ", byte count: " + size2 + ((size2 != size) ? " WRONG COUNT! Must be "+size : "") + ", CRC: " + Integer.toHexString(crc) + ((crc != calcCrc) ? " WRONG CRC! must be "+Integer.toHexString(calcCrc) : ""));
						for (int i = 0; i < count; i++) {
							int v = ((buffer[3 + i / 8] & (1 << (i % 8))) != 0) ? 1 : 0;
							if (i > 0)
								System.out.print(", ");
							System.out.print("reg" + (addr+i) + "=" + v);
						}
						System.out.println("\n");
					}
				} else if ((func == 3) || (func == 4)) {
					if (!readToBuffer(2, 6, 100))
						continue;
					int addr = ModbusPdu.bytesToInt16(buffer[3], buffer[2], true);
					int count = ModbusPdu.bytesToInt16(buffer[5], buffer[4], true);
					int crc = ModbusPdu.bytesToInt16(buffer[6], buffer[7], true);
					int calcCrc = ModbusPdu.calcCRC16(buffer, 0, 6);
					System.out.println("Request: " + ModbusPdu.toHex(buffer, 0, 8));
					System.out.println("ID: " + id + ", Fn: " + fstr + ", addr: " + addr + ", count: " + count + ", CRC: " + Integer.toHexString(crc) + ((crc != calcCrc) ? " WRONG CRC! Must be "+Integer.toHexString(calcCrc) : ""));
					if ((count < 1) || (count > MAX_READ_REGS))
						System.out.println("BAD REGISTERS COUNT: " + count);
					else {
						// Response
						int size = count * 2;
						if (!readToBuffer(0, size+5, 500))
							continue;
						int id2 = buffer[0];
						int func2 = buffer[1];
						int size2 = ((int) buffer[2]) & 0xFF;;
						crc = ModbusPdu.bytesToInt16(buffer[size+3], buffer[size+4], true);
						calcCrc = ModbusPdu.calcCRC16(buffer, 0, size+3);
						System.out.println("Response: " + ModbusPdu.toHex(buffer, 0, size+5));
						System.out.println("ID: " + id2 + ", Fn: " + func2 + ", byte count: " + size2 + ((size2 != size) ? " WRONG COUNT! Must be "+size : "") + ", CRC: " + Integer.toHexString(crc) + ((crc != calcCrc) ? " WRONG CRC! must be "+Integer.toHexString(calcCrc) : ""));
						for (int i = 0; i < count; i++) {
							int v1 = ModbusPdu.bytesToInt16(buffer[4 + i * 2], buffer[3 + i * 2], false);
							int v2 = ModbusPdu.bytesToInt16(buffer[4 + i * 2], buffer[3 + i * 2], true);
							if (i > 0)
								System.out.print(", ");
							System.out.print("reg" + (addr+i) + "=" + v1 + (v1 < 0 ? ("(" + v2 + ")") : ""));
						}
						System.out.println("\n");
					}
				} else if ((func == 5) || (func == 6)) {
					if (!readToBuffer(2, 6, 100))
						continue;
					int addr = ModbusPdu.bytesToInt16(buffer[3], buffer[2], true);
					int value = ModbusPdu.bytesToInt16(buffer[5], buffer[4], false);
					int crc = ModbusPdu.bytesToInt16(buffer[6], buffer[7], true);
					int calcCrc = ModbusPdu.calcCRC16(buffer, 0, 6);
					System.out.println("Request: " + ModbusPdu.toHex(buffer, 0, 8));
					System.out.println("ID: " + id + ", Fn: " + fstr + ", addr: " + addr + ", value: " + value + ", CRC: " + Integer.toHexString(crc) + ((crc != calcCrc) ? " WRONG CRC! Must be "+Integer.toHexString(calcCrc) : ""));
					// Response
					if (!readToBuffer(0, 8, 500))
						continue;
					int id2 = buffer[0];
					int func2 = buffer[1];
					int addr2 = ModbusPdu.bytesToInt16(buffer[3], buffer[2], true);
					int value2 = ModbusPdu.bytesToInt16(buffer[5], buffer[4], false);
					crc = ModbusPdu.bytesToInt16(buffer[6], buffer[7], true);
					calcCrc = ModbusPdu.calcCRC16(buffer, 0, 6);
					System.out.println("Response: " + ModbusPdu.toHex(buffer, 0, 8));
					System.out.println("ID: " + id2 + ", Fn: " + func2 + ", addr: " + addr2 + ((addr2 != addr) ? " WRONG ADDR! Must be "+addr : "") + ", value: " + value2 + ((value2 != value) ? " WRONG VALUE! Must be "+value : "") + ", CRC: " + Integer.toHexString(crc) + ((crc != calcCrc) ? " WRONG CRC! must be "+Integer.toHexString(calcCrc) : ""));
					System.out.println("\n");
				} else if ((func == 15) || (func == 16)) {
					
				} else {
					System.out.println("ID: " + id + ", UNKNOWN FUNCTION: " + func + "\n");
					//System.out.println(ModbusPdu.toHex(buffer, 0, 6));
				}

//				// function (bit7 means exception)
//				if (!readToBuffer(1, 1, modbusClient))
//					return ModbusClient.RESULT_TIMEOUT;
//				if ((buffer[1] & 0x7f) != modbusClient.getFunction()) {
//					logData("bad function", 0, 2);
//					log.warn("waitResponse(): Invalid function: {} (expected: {})", buffer[1], modbusClient.getFunction());
//					return ModbusClient.RESULT_BAD_RESPONSE;
//				}

			}
			
		} catch (SerialPortException e1) {
			e1.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			try {
				if (port.isOpened())
					port.closePort();
			} catch (SerialPortException e) {
				e.printStackTrace();
			}
		}
	}

}
